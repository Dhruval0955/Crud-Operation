from django.db import models

# Create your models here.

class Customer(models.Model): 
    first_name = models.EmailField(max_length=25) 
    last_name = models.CharField(max_length=25) 
    contact_no = models.CharField(max_length=15)           
    pincode = models.IntegerField() 


class Item(models.Model): 
    name = models.CharField(max_length=50)
    unit_price = models.DecimalField(max_digits=6,
    decimal_places=2)



class Order(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)

    item = models.ForeignKey(Item,on_delete=models.CASCADE)

    order_price = models.DecimalField(max_digits=6,
    decimal_places=2)

    qty = models.IntegerField()

    total_price = models.DecimalField(max_digits=10,
    decimal_places=2)

    created_date = models.DateTimeField(auto_now_add=True)



