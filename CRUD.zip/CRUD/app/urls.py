from django.urls import path,include
from .import views
urlpatterns = [
    path("customer/",views.Customerpage,name="customer"),
    path("adddata/",views.Insertdata,name="adddata"),
    path("show/",views.Showdata,name="show"),

    ############ PRODUCT ################
    path("product/",views.Product,name="product"),
    path("addpdata/",views.ProductInsertdata,name="addpdata"),
    path("plist/",views.ShowProduct,name='plist'),
    path("fetchprise/",views.fetchprise,name="fetchprise"),


    ################### Order ####################

    path("order/",views.Order,name="order"),


]  

