from django.http.response import HttpResponse
from django.shortcuts import render,redirect
from .models import*
from django.http import JsonResponse
from django.core import serializers
# Create your views here.

def Customerpage(request):
    return render(request,"app/customer.html")
    

def Insertdata(request):
    fname =  request.POST['fname']
    lname = request.POST['lname']
    contact_num = request.POST['cnt']
    pcode = request.POST['pin']

    idata = Customer.objects.create(
        first_name = fname,
        last_name = lname,
        contact_no = contact_num,
        pincode   = pcode
    )
    return redirect('show')
   

def Showdata(request):
    cdata = Customer.objects.all()
    return render(request,"app/list.html",{'data':cdata})

    

def Product(request):
    return render(request,"app/product.html")


def ProductInsertdata(request):
    prname =  request.POST['name']
    uprice = request.POST['price']
    
    pdata = Item.objects.create(
        name = prname,
        unit_price = uprice
        
    )
    return redirect('plist')

def ShowProduct(request):
    cdata = Item.objects.all()
    return render(request,"app/productlist.html",{'data':cdata})
    


def Order(request):
    cdata = Customer.objects.all()
    idata = Item.objects.all()

    return render(request,"app/order.html",{'cdata':cdata, 'idata':idata})

def fetchprise(request):
    id1=request.POST['id']
    
    #data = serializers.serialize("json",Item.objects.get(id=id1))
    data={}
    data=Item.objects.get(id=id1)
    
    
    return HttpResponse(data)

    
          
    
